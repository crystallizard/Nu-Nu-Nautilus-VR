﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[RequireComponent(typeof(AudioSource))] 
[RequireComponent(typeof(Light))] 
[RequireComponent(typeof(Shader))] 
[RequireComponent(typeof(ParticleSystem))] 

public class onTrigger : MonoBehaviour {

	public GameObject theobject;
	//public AudioSource audiotoplay;
	//public Light lighttoplay;
	//public GameObject objecttomove;
	//public Collider Sphere;
	public bool enterswitch;
	public bool stayswitch;
	public bool exitswitch;
	public Vector3 onenterPosition;
	public string entertext;
	public string exittext;
	public bool killswitch;
	public Vector3 rotation;
	public float rotationspeed;



	void OnTriggerEnter(Collider Sphere)
	{
		print (entertext);
		AudioSource audio = GetComponent<AudioSource>();
		audio.Play();
		Light lamp = GetComponent<Light>();
		lamp.intensity = 12;
	//	Shader shader = GetComponent<Shader> ();
	//	Shader.
		theobject.transform.Rotate (rotation, rotationspeed);
		ParticleSystem particle = GetComponent<ParticleSystem> ();
		//particle.Emit (20);



	}

	void OnTriggerStay(Collider Sphere)
	{
		Light lamp = GetComponent<Light>();
		lamp.intensity = 5;

	}

	void OnTriggerExit(Collider Sphere)
	{
		Light lamp = GetComponent<Light>();
		lamp.intensity = 0;
		theobject.transform.Rotate (0,0,0);
		if (killswitch == true) {
	
			Destroy (theobject);
		}
	
	}

	// Use this for initialization
	void Start () {
		
	
	}
	
	// Update is called once per frame
	void Update ()
	{

	
			
	}



}